/*:
 # Enums and switch statements
 
 An enumeration, or enum, defines a common type for a group of related values and enables you to work with those values in a type-safe way within your code.
 
 Part 1: Enumeration Syntax
 
 You introduce enumerations with the enum keyword and place their entire definition within a pair of braces:
 
 enum SomeEnumeration {
 // enumeration definition goes here
 }
 Here’s an example for the four main points of a compass:
 
 enum CompassPoint {
 case north
 case south
 case east
 case west
 }
 The values defined in an enumeration (such as north, south, east, and west) are its enumeration cases. You use the case keyword to introduce new enumeration cases.
 
 
 
 
 
 
 
 
 
 
 
 We will try a couple of different switch statement exercises

 Simple enum for days of week
*/

enum daysOfWeek: Int {
    case Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
}

print( daysOfWeek.Sunday.rawValue )   // Will be 7


var today = daysOfWeek.Monday
var whatToDo = ""
switch today{
case .Saturday, .Sunday:
    whatToDo = "Chill - it's the weekend"
default:
    whatToDo = "Apply nose to grindstone"
}

print( whatToDo ) // Will print “Apply nose to grindstone”

today = .Saturday // As we know type of today now, I don’t need to say “daysOfWeek”

/*:

Car example
*/

enum carReg {
    case New( String, Int, String )
    case Old( String, String, String )
    case Custom( String, Int )
}

func yearOfRegistration( carDets: carReg ) -> String{
    var result =  "unknown"
    switch carDets {
    case let .New(_, middle, _):
         if middle >= 50 {
            result = "\(1950+middle)"
        } else {
            result = "\(2000+middle)"
        }
        // How would you replace the default by separate cases?
    case let .Old(start, middle, end):
        print( end + start + middle )
    default:
        break
    }
    return result
}

yearOfRegistration(carDets: carReg.New("CP", 57, "BHO"))
yearOfRegistration(carDets: carReg.New("HY", 07, "FPB"))
yearOfRegistration(carDets: carReg.Old("BOB", "007", "B"))  //Should be 1984

yearOfRegistration(carDets: carReg.Custom( "Q103LOL", 1993)) //Should be 1993

yearOfRegistration(carDets: .Custom( "XDOTDOT", 1984 )) // 1984


/*:
Here is an example of using a Switch statement with pattern matching to decide whether people are allowed to drink in a specified country, given their age.
*/


func allowedToDrink( age: Int, _ country: String ) -> String{
    switch (age, country){
    case (_, "Saudi Arabia"):
        return "Not allowed"
    case (let myAge, _) where age < 5:
        return "Infants of \(myAge) are never allowed"
    case (_, "United States" ):
        if age >= 21 {return "Allowed"}
        else {return "Not allowed"}
    default:
        return "Unknown"
    }
}

allowedToDrink(age: 44, "Saudi Arabia")
allowedToDrink(age: 4, "England")
allowedToDrink(age: 20, "United States")
allowedToDrink(age: 20, "Greece")
allowedToDrink(age: 17, "Mauritius" )

/*:
Now try to add some more cases to the allowedToDrink example:

It is never allowed in Libya and the Sudan.
Legal age is 18 in UK, Mauritius, Greece and Bermuda
*/

/*:
 Well done, you have completed this Playground!
 */
