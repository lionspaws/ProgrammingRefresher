/*:
 # Enums and Switch Statements
 
 An enumeration, or enum, defines a common type for a group of related values and enables you to work with those values in a type-safe way within your code.
 
 ## Exercise 1: Enum syntax
 
 You introduce enums with the `enum` keyword and place their entire definition within a pair of braces. The enum name becomes a type, so it should start with a capital letter (like `String`, `Int`, `Double`,...)
 
    enum SomeEnumeration {
        // enumeration definition goes here
    }
 
 Here’s an example for the four main points of a compass:
 */
enum CompassPoint {
    case north
    case south
    case east
    case west
}
/*:
 The values defined in an enumeration (such as `north`, `south`, `east`, and `west`) are its enumeration cases. You use the `case` keyword to introduce new enumeration cases. You can also define the cases on one line like this:
 */
enum Planet {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
}
/*:
 Try writing an enum for the days of the week.
 */
// write your code here:

/*:
 You can refer to enums using the type:
 */
var heading = CompassPoint.west
/*:
 Or if the type is pre-assigned, you can use this shorthand:
 */
var direction:CompassPoint
direction = .east
/*:
 ## Exercise 2: Switch enums
 
 We looked at switch statements in Playground 2. Enums and switch statements work well together.
 
 Here is an example using the `CompassPoint` enum and `heading` variable created earlier:
 */
heading = .south
switch heading {
case .north:
    print("Lots of planets have a north")
case .south:
    print("Watch out for penguins")
case .east:
    print("Where the sun rises")
case .west:
    print("Where the skies are blue")
}
/*:
 Try creating a switch statement using the `Planet` enum:
 
 * for Earth, print "Mostly harmless"
 * for Mars, print "There may be life"
 * otherwise print "Not a safe place for humans"
 */
// write your code here:

/*:
 ## Exercise 3: Associated values
 
 Sometimes it's useful to be able to store extra information along with the enum case value.
 
 Associated values are set when you create a new constant or variable based on one of the enumeration’s cases, and can be different each time you do so.
 
 This example stores two different types of code, each of which need different information associated with them:
 */
enum Barcode {
    case upc(Int, Int, Int, Int)
    case qrCode(String)
}

// declare a variable using the upc case, store 4 ints
var productBarcode = Barcode.upc(8, 85909, 51226, 3)
var productBarcode2 = Barcode.upc(1, 1, 1, 1)

// but if you change the same variable to use the qrCode case, is changes to a single string
productBarcode = .qrCode("ABCDEF")
/*:
 Create an enum to store library information with the following cases:
 
 * Book: title, author, year
 * Magazine: title, issue, year
 * Film: title, year
 * TV Show: title, number of episodes, number of seasons
 
 Choose relevant associated values for each case.
 */
//write your code here:

/*:
 Try your enum by creating two new Library objects:
 
 * a book: "The Martian" by Andy Weir, published 2011.
 * a film: "The Martian", released in 2015.
*/
//write your code here:

/*:
 ## Exercise 4: Raw values
 
 As an alternative to associated values, enumeration cases can come prepopulated with default values (called raw values), which are all of the same type.
 
 The raw value for a particular enumeration case is always the same, and each raw value must be unique within its enumeration declaration.
 
 Here's an example of declaring and getting raw values of an enum:
 */
enum NewCompassPoint:String {
    case north = "N"
    case south = "S"
    case east = "E"
    case west = "W"
}
NewCompassPoint.north.rawValue
/*:
 When you’re working with enumerations that store integer or string raw values, you don’t have to explicitly assign a raw value for each case. When you don’t, Swift will automatically assign the values for you.
 
 For instance, when integers are used for raw values, the implicit value for each case is one more than the previous case. If the first case doesn’t have a value set, its value is 0:
 */
enum NumberedPlanet:Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune
}
NumberedPlanet.jupiter.rawValue
NumberedPlanet(rawValue: 5)
/*:
 Write a new version of your days of the week enum to have the days of the week numbered, starting with saturday as day 1.
 */
// write your code here:

/*:
 ## Exercise 5: Week planner
 
 Write a switch to return the activities of the day based on the weekday using your enum for days of the week.
 
 * During weekdays you will be at work
 * On Tuesday evenings you also go to photography club
 * On Wednesday afternoons you leave work early to go swimming
 * On the weekends you relax
 */
// write your code here:

/*:
 Well done, you have completed this Playground!
 */
