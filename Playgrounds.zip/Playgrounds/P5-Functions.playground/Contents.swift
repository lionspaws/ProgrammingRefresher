/*: 
 # Functions
 
 Functions are self-contained chunks of code that perform a specific task. You give a function a name that identifies what it does, and this name is used to "call" the function to perform its task when needed.
 
 ## Exercise 1: Declaring basic functions
 
 Every function definition:
 
 * starts with the `func` keyword
 * a function name, which describes the task that the function performs
 * curly brackets containing the function's code
 
*/
func myBasicFunction() {
    print("Good afternoon")
}
/*:
 A function may also have:
 
 * a return type, indicated with the return arrow `->` (a hyphen followed by a right angle bracket) followed by the name of the type to return
 * a return statement which returns a value corresponding to the type you specified
 
 The definition describes what the function does, what it expects to receive, and what it returns when it is done.
 
 Here's a very simple example function which returns the `String greeting`:
*/
func myFunction() -> String {
    // you can return values using variables, constants, and direct values (see myBasicFunction)
    let greeting = "Hello"
    return greeting
}
/*:
 To use a function, you "call" that function with its name.
*/
myBasicFunction()   // this will print "Good afternoon" to the console
myFunction()        // this will not print to the console, but you can see the result of calling it in the sidebar
/*:
 The number of times you call a function within the Playground will be counted and may be displayed in the sidebar, e.g. (2 times).
 
 You can call functions in useful places, e.g.
 */
// print the result of myFunction, followed by ", world!"
// check the console to see the output...
print("\(myFunction()), world!")
/*:
 Try creating you own function that uses a loop to count from 10 down to 1, and return the `String` "10, 9, 8, 7, 6, 5, 4, 3, 2, 1, Done!" when it's finished.
 */
// write your code here:

/*:
 ## Exercise 2: Arguments, many arguments
 
 Functions become very powerful when they are set up to act upon information you provide. 
 
 You can pass a function input values, known as arguments. You must specify the types of the arguments your function is expecting, and a function’s arguments must always be provided in the same order as the function’s parameter list.
 
 Here's an example using one argument:
 */
// Example 1: a greeting for friendly neighbours
func myFriendlyGreeting(sayHello: Bool) {
    if sayHello {
        print("\(myFunction())")    // say hello!
    }
    else {
        print("🙂")
    }
}

myFriendlyGreeting(sayHello: false)
/*:
 And here's an example using three arguments:
 */
// Example 2: a greeting for less friendly people
func myUnfriendlyGreeting(sayHello: Bool, nemesis: Bool, theirName: String) -> String {
    var greeting = ""
    if sayHello {
        if !nemesis {
            greeting = "Hello, \(theirName)!"
        }
        else {
            greeting = "😠 \(theirName)."
        }
    }
    else {
        greeting = "stony silence..."
    }
    return greeting
}

myUnfriendlyGreeting(sayHello: false, nemesis: true, theirName: "Voldemort")
/*:
 Try improving on our original greeting function's capabilities so you can provide a name to get a personalised greeting.
*/
// write your code here:

/*:
 ## Exercise 3: Temperature conversions
 
 Try creating a function which will convert temperatures. It should take an input temperature in fahrenheit, convert it, and return the temperature in centrigrade. The formula to convert the temperatures is: 
 
 `centrigrade = (fahrenheit - 32) / 1.8`
*/
// write your code here:

/*:
 Using your function, try the following conversions to see if you get the right answers:
 
 * 32℉ = 0℃
 * -40℉ = -40℃
 * 212℉ = 100℃
 * 0℉ = -17.78℃
 */
// write your code here:

/*:
 ## Exercise 4: Multiple return values
 
 You can use a *tuple* type as the return type for a function to return multiple values as part of one compound return value.
 
 Here's a function that takes an `Int` variable and returns a `Tuple` containing a `Int` and a `Bool`
*/
func ageAndPensioned(birthYear: Int) -> (age: Int, pensioned: Bool){
    let age = 2017 - birthYear
    return (age, age > 65)
}
//: Let's try the function out...
var age: Int
var pensioned: Bool
(age, pensioned) = ageAndPensioned(birthYear: 1922)
//: Tuples are displayed in the sidebar with their element ID, e.g. 0, 1, 2, ...
let answer = ageAndPensioned(birthYear: 1982)
answer.age
answer.pensioned
/*:
 ## Exercise 5: Weather reporting
 
 Create a function which will take a temperature and season as input, and return a simple weather report in the form of a comment and a boolean weather warning:
 
 * Seasons: spring, summer, autumn, winter
 * Temperature: a number in centrigrade between -20 and 50
 * Reports: Give reports such as "it's a lovely warm summer day" and "it's a frosty winter morning".
 * Warnings: If you have a very hot day (i.e. over 20℃) or a very cold day (i.e. below 0℃) you will give a weather warning. If there's a weather warning in place, it should be mentioned at the end of the report, e.g. "it's a frosty winter morning, there is a weather warning in place"
 
 */
// write your code here:

/*:
 Well done, you have completed this Playground!
*/
