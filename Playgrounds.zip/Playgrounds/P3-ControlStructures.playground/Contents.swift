/*:
 # Control structures
 
 Control structures allow your program to do something interesting after evaluating an expression, or repeat code a specific number of times. Choose the right control structure for each situation carefully, as some have subtle differences between them which you need to be aware of.
 
 These control structures are common to many programming languages but there are some variations in the way you define them.
 
 ## Exercise 1: If statements
 
 If statements allow you to direct the program to a specific consequence if it meets a specific condition.
 
 The first condition always uses `if`; use `else` when you want a case that will happen if none of the conditions you specify are met. If you have more than one condition, you can use `else if`:
 
 ````
 if comparison1 {
    // called if comparison 1 is true
 }
 else if comparison2 {
    // called if comparison 2 is true
 }
 else {
    // called if nothing else is true
 }
 ````
 Note: In Swift you must always use curly brackets around the consequence; some languages don't require this. Round brackets around the condition are optional; in some languages the round brackets are mandatory.
 
 Write an if statement which uses the variables provided below to print some text:
 
 * if the temperature is too hot, print "Turn the fan on"
 * if the temperature is too cold, print "Turn the fan off"
 * otherwise, print "Feeling fine"
*/
var temperature = 17
var comfyTemp = 18
var coldTemp = 16

// write your code here:

/*:
 Once you've finished try changing the temperature a few times to check the console output is as you expect.
 
 ## Exercise 2: For loops
 
 For loops follow the structure of repeating code over a set number of iterations. There are different ways to structure a for loop:

 ````
 for item in range {
    // do some code
    // keep repeating while the loop keeps going round
 }
 ````
*/
// Example 1: range over 1 to 5
var sum = 0
for i in 1...5 {
    sum = sum + i
}

// Example 2: range over 1 to 4
sum = 0
for i in (1..<5) {
    sum = sum + i
}
/*:
 ````
 for item in collection { 
    // do some code
    // keep repeating while the loop keeps going round
 }
 ````
*/
// Example 3: cycle through each attendee in list
var listOfAttendees = [ "Bill", "Jane", "Jim", "Fred", "Ann" ]
for name in listOfAttendees {
    // we're looking for John
    if name == "John" {
        print(name)
    }
}

// Example 4: loop through a string as characters
for character in "Dog!🐶".characters {
    print(character)
}
/*:
 One really useful feature in Playgrounds is that it will show you the progress of a loop over time. In the right sidebar you can see how many times each to the loops will run. Use the buttons to the right of the loop counter in the right sidebar to examine the loop over time.
 
 Try modifying the loops to see how the progress changes.
*/
/*:
 ## Exercise 3: While loops
 
 A while loop starts by evaluating a single condition. If the condition is true, a set of statements is repeated until the condition becomes false.
 
 Here’s the general form of a while loop:
 
    while condition {
        // do something
    }
*/
// Example 1: count down to zero with while loop
var count = 10
while count > 0 {
    count -= 1
}
print("While loop result: count = \(count)")
/*:
 A variation of the while loop is the repeat-while loop, which passes through the loop block first before considering the loop’s condition - i.e. it *ALWAYS* executes at least once. It then continues to repeat the loop until the condition is false.
 
 The repeat-while loop in Swift is analogous to a do-while loop in other languages.
 
 Here’s the general form of a repeat-while loop:
 
    repeat {
        statements
    } while condition
 */
// Example 2: count down to zero with repeat-while loop
count = 10
repeat {
    count -= 1
} while count > 0
print("Repeat-while loop result: count = \(count)")
/*:
 Try changing the starting values of `count` to 0 before both loops to see how this changes the result.

 ## Exercise 4: Switch statements
 
 A switch statement considers a value and compares it against several possible matching patterns. It then executes a block of code based on the *first pattern that matches successfully*.
 
 Every switch statement consists of multiple possible cases, each of which begins with the `case` keyword.
 
    switch some value to consider {
        case value 1:
            respond to value 1
        case value 2, value 3:
            respond to value 2 or 3
        default:
            otherwise, do something else
    }
 
 A switch statement should consider every possible case. The `default` case allows you to provide code for any cases that aren't addressed explicitly. This default case is indicated by the default keyword, and must always appear last.
 
 This example uses a switch statement to consider a single lowercase character called someCharacter:
 */
let someCharacter: Character = "z"
switch someCharacter {
    case "a":
        print("The first letter of the alphabet")
    case "z":
        print("The last letter of the alphabet")
    default:
        print("Some other character")
}
/*:

 **One very important difference** between Swift and many other languages: you may have noticed the absence of `break`. 
 
 Swift does not allow you to fall through cases. Instead, the entire switch statement finishes its execution as soon as the first matching switch case is completed, without requiring an explicit break statement. This makes the switch statement safer and easier to use than the one in C and avoids executing more than one switch case by mistake.
 
 NOTE: Although break is not required in Swift, you can use a break statement to match and ignore a particular case or to break out of a matched case before that case has completed its execution.
 
 Write your own switch statement which will print the sound given by the pet in `petName`:
 
 * Lassie, Snoopy = "woof"
 * Crookshanks = "meow"
 * Daffy = "quack"
 * default = "*silence*"
 */
let petName = "Snoopy"

// write your code here:

/*:
 ## Exercise 5: Buzz
 
 Using the structures we've looked at in this Playground, we are going to write a program called "Buzz".
 
 Write a loop that goes from 1 to 100, and prints "buzz" if the number is divisible by 3 and the number if it is not.
 
 Hint: if `number % 3 == 0` then it is divisible by 3
*/
// write your code here:

/*:
 Well done, you have completed this Playground!
*/
