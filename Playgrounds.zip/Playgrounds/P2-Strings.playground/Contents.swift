/*: 
 # Strings and Characters

 A string is a series of characters, such as `"hello, world"` or `"albatross"`. Swift strings are represented by the String type. The contents of a `String` can be accessed in various ways, including as a collection of `Character` values.

 ## Exercise 1: Defining characters and string literals
 
 You can define characters using the character itself or the Unicode for it, e.g.:
 */
// a character
var singleCharacter:Character = "b"

// a string of characters
var greeting = "Hello"

// Unicode
let dollarSign:Character = "\u{24}"
let sparklingHeart = "\u{1F496}"
/*:
 You can include predefined `String` values within your code as string literals. A string literal is a sequence of characters surrounded by double quotes (`"`). 
 
 Use a string literal as an initial value for a constant or variable:
 */
let someString:String = "Some string literal value"
/*:
 Remember, you can print strings and values by using the `print()` function in Swift.
 
 You can mix bits of text and other values by doing 'string interpolation'. Put variables inside \( and ) to use them inside a String.
 */
var theAnswer = 42
var myString = "The answer to life, the universe and everything is \(theAnswer)"
/*:
 Try using string interpolation and arithmetic with `value` to create a constant answer which will contain the string `"4.6 + 4.6 = 9.2"`
 */
var value = 4.6

// write your code here:

/*:
 ## Exercise 2: String operations

 There are several ways to declare an empty `String`:
 */
var lackOfString: String
var emptyString = ""
var anotherEmptyString = String()
/*:
 `String` values can be added together (or concatenated) with the addition operator (`+`) to create a new `String` value:
 */
let string1 = "hello"
let string2 = " there"
var welcome = string1 + string2
/*:
 You can also append a `String` value to an existing `String` variable with the addition assignment operator (`+=`):
 */
var instruction = "look over"
instruction += string2
/*:
 You can append a `Character` value to a `String` variable with the `String` type’s `append()` method:
 */
let exclamationMark: Character = "!"
welcome.append(exclamationMark)
/*:
 Swift provides a range of useful functions, including:
 
 * `isEmpty`
 * `hasPrefix(prefix: String)`
 * `hasSuffix(suffix: String)`
 * `characters.count` (e.g. `myStr.characters.count`)
 
 Try each of these with the provided `politeGreeting`:
 */
var politeGreeeting = greeting + ", my friend"
// write your code here:

/*:
 ## Exercise 3: String comparison
 
 String and character equality is checked with the "equal to" operator (`==`) and the "not equal to" operator (`!=`).
*/
let quotation = "We're a lot alike, you and I."
let sameQuotation = "We're a lot alike, you and I."
quotation == sameQuotation
/*:
 Try comparing these `Strings` - what do the results show?
 
 * is "aardvark" equal to "penguin"?
 * is "aardvark" equal to "aard" + "vark"?
 * is "aardvark" less than "penguin"?
 * is "quail" less than "penguin"?
 */
// write your code here:

/*:
 Well done, you have completed this Playground!
 */
