/*:
 # Collections
 
 Swift provides three primary collection types, known as arrays, sets, and dictionaries, for storing collections of values. Arrays are ordered collections of values. Sets are unordered collections of unique values. Dictionaries are unordered collections of key-value associations.
 
 ## Exercise 1: Arrays
 
 An array stores values of the same type in an ordered list. The same value can appear in an array multiple times at different positions.
 
 The type of a Swift array is written in full as `Array<Element>`, where `Element` is the type of values the array is allowed to store. You can also write the type of an array in shorthand form as `[Element]`.
 
 You can create an empty array of a certain type using initializer syntax:
*/
var someInts = [Int]()
var myString = "someInts is of type [Int] with \(someInts.count) items."
/*:
 Swift’s Array type also provides an initializer for creating an array of a certain size with all of its values set to the same default value.
 */
var threeDoubles = Array(repeating: 0.0, count: 3)
var threeStrings = Array(repeating: "Ha", count: 3)
/*:
 You can create a new array by adding together two existing arrays with compatible types with the addition operator (+). The new array’s type is inferred from the type of the two arrays you add together:
 */
var anotherThreeDoubles = Array(repeating: 2.5, count: 3)
var sixDoubles = threeDoubles + anotherThreeDoubles
/*:
 You can also initialize an array with an array literal, which is a shorthand way to write one or more values as an array collection. An array literal is written as a list of values, separated by commas, surrounded by a pair of square brackets:
 
    [value 1, value 2, value 3]
 */
var setOfDoubles: [Double] = [1.0, 2.0]
myString = "setOfDoubles contains \(setOfDoubles.count) items."

if setOfDoubles.isEmpty {
    myString = "The set of Doubles is empty."
} else {
    myString = "The set of Doubles is not empty, it contains: \(setOfDoubles)"
}
/*:
 You can add/remove elements to/from the array:
 */
someInts.append(2)                  // using append
someInts += [5, 7, 11, 13, 17, 19]  // the addition assignment operator (+=)
someInts.insert(3, at: 1)           // by inserting elements at a specified index, where the first element is always at index 0

someInts.remove(at: 1)      // remove at a given index
someInts.popLast()          // remove the last element
someInts.removeFirst(2)     // remove the first n element(s), also `removeLast(n)`
someInts.removeFirst()      // remove the first element, also `removeLast`
someInts
someInts = []
/*:
 Create an array called `shoppingList`, initialised to contain only "Eggs" and "Milk". Append "Baking Powder", "Chocolate Spread", "Cheese",  and "Butter". Insert "Maple Syrup" at the very beginning of the list.
 */
// write your code here:

/*:
 Using an if statement and a for loop, check if the list is empty. If it isn't, print the results in the following format:
 
    The shopping list contains 3 items:
    - Cheese
    - Milk
    - Butter
 */
// write your code here:

/*:
 ## Exercise 2: Sets
 
 A set stores distinct values of the same type in a collection with no defined ordering. You can use a set instead of an array when the order of items is not important, or when you need to ensure that an item only appears once.
 
 The type of a Swift set is written as Set<Element>, where Element is the type that the set is allowed to store. Unlike arrays, sets do not have an equivalent shorthand form.
 */
var letters = Set<Character>()
myString = "letters is of type Set<Character> with \(letters.count) items."
letters.insert("a")
letters = []
/*:
 Sets have similar functionality to arrays with different syntax:
 */
// add and remove elements
var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip hop"]
favoriteGenres.insert("Pop")
favoriteGenres.insert("Jazz")
favoriteGenres.remove("Hip hop")

// count the elements
myString = "I have \(favoriteGenres.count) favorite music genres: "

// use sorted() to sort the elements - how are they being sorted?
for genre in favoriteGenres.sorted() {
    if genre == favoriteGenres.sorted().last {
        myString += "and \(genre)."
    }
    else {
        myString += "\(genre), "
    }
}
print(myString)
/*:
 You can efficiently perform fundamental set operations, such as combining two sets together, determining which values two sets have in common, or determining whether two sets contain all, some, or none of the same values. 
 
 Take a look at the diagrams in the booklet to see how this works.
 
 Using the three sets provided, try using the following set operations. What do the results tell you?
 
 * union of `oddDigits` and `evenDigits`
 * intersection of `oddDigits` and `evenDigits`
 * subtract `singleDigitPrimeNumbers` from `oddDigits`
 * get the symmetric difference of `singleDigitPrimeNumbers` and `oddDigits`
 */
let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

// write your code here:

/*:
 Hint: using `sorted` will make it much easier to read the results.
 
 Here are three more useful set operations, what do you think they do?
 */
let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

houseAnimals.isSubset(of: farmAnimals)
farmAnimals.isSuperset(of: houseAnimals)
farmAnimals.isDisjoint(with: cityAnimals)
/*:
 ## Exercise 3: Dictionaries
 
 A dictionary stores associations between keys of the same type and values of the same type in a collection with no defined ordering. Each value is associated with a unique key, which acts as an identifier for that value within the dictionary. 
 
 Unlike items in an array, items in a dictionary do not have a specified order. You use a dictionary when you need to look up values based on their identifier, in much the same way that a real-world dictionary is used to look up the definition for a particular word.
 */
var namesOfIntegers = [Int: String]()
namesOfIntegers[16] = "sixteen"
namesOfIntegers = [:]
/*:
 You can also initialize a dictionary with a dictionary literal, which has a similar syntax to the array literal seen earlier:
 
    [key 1: value 1, key 2: value 2, key 3: value 3]
 
 Here's an example of a dictionary:
 */
var airports: [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]

// add new elements
airports["LHR"] = "London"
airports["APL"] = "Apple International"

// update elements
airports["LHR"] = "London Heathrow"
airports.updateValue("Dublin Airport", forKey: "DUB")

// remove elements
airports["APL"] = nil
airports.removeValue(forKey: "YYZ")
/*:
 You can iterate over dictionaries in several ways:
 */
// using key-value pairs
for (airportCode, airportName) in airports {
    myString = "\(airportCode): \(airportName)"
    //print(myString)
}
// using just keys or values
for airportCode in airports.keys {
    myString = "Airport code: \(airportCode)"
    //print(myString)
}
for airportName in airports.values {
    myString = "Airport name: \(airportName)"
    //print(myString)
}
/*:
 Create a dictionary of pets containing the following pets:
 
 * Dave the goldfish
 * Chaz the dog
 * Idris the guinea pig
 */
// write your code here:

//: Add a new guinea pig called Murphy to the list and update Dave to be a Common Goldfish
// write your code here:

/*:
 Print a list of the pets in the format "`name` is a `animal`" using a key-value pair loop.
*/
// write your code here:

/*:
  Try printing a list of the pets in the formats "`name` is a pet" and "We have a `animal`" using two separate loops for keys and values.
 */
// write your code here:

/*:
 Well done, you have completed this Playground!
 */
