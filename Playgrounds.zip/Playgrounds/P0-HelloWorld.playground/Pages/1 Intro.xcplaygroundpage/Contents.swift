/*:
 # Welcome to Playgrounds
 Playgrounds allow you to explore what code does interactively.
 
 On the right hand side, the sidebar shows you what each line of code will produce. At the bottom of the IDE, the Debug Area will give you the actual result of running the whole program.
*/
print("Hello, World!")
//: Well done, you have completed this Playground!
