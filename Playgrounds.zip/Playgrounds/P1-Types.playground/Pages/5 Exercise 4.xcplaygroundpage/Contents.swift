//: [Previous](@previous)

/*:
 ## Exercise 4: Expressions
 
 Expressions are the same as in most languages. Type safety means that you sometimes have to specify a type in the expression. For example, try adding value and realValue declared earlier together. You will find that you need to put `Double()` around value to get it to work.
 */
// write your code here:
//var newValue = Double(value) + realValue
/*:
 You can mix bits of texts and other values by doing 'string interpolation'. Put variables inside `\(` and `)`, and they will be evaluated:
 */
// write your code here:
//let answer = "\(value) + \(value) = \(value+value)"
/*:
 In a Swift program, you would use `print()` to print things. In Playgrounds, you can just write an expression and it will be evaluated and appear in the sidebar to the right.
 */
// write your code here:
//print(answer)
/*:
 Other things to try:
 
 * Try evaluating the string `str` as part of a larger string.
 * You can concatenate strings by using the `+` operator.
 */
// write your code here:
//let newString = str + "; did you know " + answer + "?"

//: [Next](@next)
