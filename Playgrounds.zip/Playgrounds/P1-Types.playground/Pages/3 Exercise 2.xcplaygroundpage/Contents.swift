//: [Previous](@previous)
/*:
 ## Exercise 2: Variables and constants
 
 Variables can hold values which change during the program. If you are not going to change the value of a variable, you are strongly encouraged to make it a constant so that the compiler can optimise it. You do this by using `let` instead of `var`:
 
    let pi = 3.1412
 
 Try changing the declaration of `myStr` to use `let` instead of `var` and see what happens.
 */
// Note that you can use Emoji in Swift, but not all languages allow this! 😔
var myStr = "Hello, playground! 🙂"
myStr = "Goodbye, playground! 🙁"
/*:
 Playgrounds will help you to fix many errors - try clicking on the red circle to the left of the line. You will want to change the declaration back to `var`, as an error in a Playground stops all later code from executing.
 */

//: [Next](@next)