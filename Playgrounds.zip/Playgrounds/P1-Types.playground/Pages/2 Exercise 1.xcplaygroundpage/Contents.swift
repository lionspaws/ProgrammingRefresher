//: [Previous](@previous)
/*:
 ## Exercise 1: Simple types
 
 Try declaring variables with the following values in the space below and see what types and outputs you get.
 
 * 1
 * 3.2
 * true
 * [ "a", "be", "sea"]
 */
// write your code here:
//var a = 1
//var b = 3.2
//var c = true
//var d = [ "a", "be", "sea"]
//: [Next](@next)