/*:
 # Understanding Playgrounds and declaring values
 Playgrounds allow you to explore what code does interactively.
 It is possible to type code and see what it does.

 ## Getting started
 
 The code below is what you get when you start a new iOS playground.

 On the right, you can see what the value of str is.
 If you alt-click on `str`, it will tell you its type.
*/
import UIKit

var str = "Hello, playground"

/*:
 ## Exercise 1: Simple types
 
 Try declaring variables with the following values in the space below and see what types and outputs you get.
 
 * 1
 * 3.2
 * true
 * [ "a", "be", "sea"]
 */
// write your code here:
//var a = 1
//var b = 3.2
//var c = true
//var d = [ "a", "be", "sea"]
/*:
 ## Exercise 2: Variables and constants
 
 Variables can hold values which change during the program. If you are not going to change the value of a variable, you are strongly encouraged to make it a constant so that the compiler can optimise it. You do this by using `let` instead of `var`:
 
    let pi = 3.1412

 Try changing the declaration of `myStr` to use `let` instead of `var` and see what happens.
*/
// Note that you can use Emoji in Swift, but not all languages allow this! 😔
var myStr = "Hello, playground! 🙂"
myStr = "Goodbye, playground! 🙁"
/*:
 Playgrounds will help you to fix many errors - try clicking on the red circle to the left of the line. You will want to change the declaration back to `var`, as an error in a Playground stops all later code from executing.
 
 ## Exercise 3: Specific types

 Where there is ambiguity over a declaration, you can give a specific type:
*/
let value: Float = 4.6
let realValue: Double = 4
var saying: String
/*:
 Try declaring a constant `Int` without giving it a value.
Why is that OK?
*/
// write your code here:
//let myInt: Int
/*:
 Try declaring another constant `Int` and giving it the value of the constant you just created.
 Why is that NOT OK?
*/
// write your code here:
//myInt = 12
//let myOtherInt: Int = myint
/*:
 Try setting the value of the first constant you declared BEFORE using it. That fixes it.
 
 ## Exercise 4: Expressions
 
 Expressions are the same as in most languages. Type safety means that you sometimes have to specify a type in the expression. For example, try adding value and realValue declared earlier together. You will find that you need to put `Double()` around value to get it to work.
*/
// write your code here:
//var newValue = Double(value) + realValue
/*: 
 You can mix bits of texts and other values by doing 'string interpolation'. Put variables inside `\(` and `)`, and they will be evaluated:
*/
// write your code here:
//let answer = "\(value) + \(value) = \(value+value)"
/*:
 In a Swift program, you would use `print()` to print things. In Playgrounds, you can just write an expression and it will be evaluated and appear in the sidebar to the right.
 */
// write your code here:
//print(answer)
/*:
 Other things to try:
 
 * Try evaluating the string `str` as part of a larger string.
 * You can concatenate strings by using the `+` operator.
 */
// write your code here:
//let newString = str + "; did you know " + answer + "?"
/*:
 Well done, you have completed this Playground!
*/
